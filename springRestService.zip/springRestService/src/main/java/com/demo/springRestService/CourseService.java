package com.demo.springRestService;

public interface CourseService {

	String addCourse(Courses course);

}
