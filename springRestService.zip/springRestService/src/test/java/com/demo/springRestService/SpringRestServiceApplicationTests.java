package com.demo.springRestService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
